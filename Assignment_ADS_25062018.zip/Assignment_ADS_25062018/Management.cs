﻿using System;
namespace Assignment_ADS_25062018.Models
{
    public class Management
    {
        public Management()
        {
        }

        public int StaffID { get; set; }

        public static void GenerateDailyReport()
        {
            throw new NotImplementedException();
        }

        public static void GenerateWeeklyReport()
        {
            throw new NotImplementedException();
        }

        public static void GenerateMonthlyReport()
        {
            throw new NotImplementedException();
        }
    }
}
